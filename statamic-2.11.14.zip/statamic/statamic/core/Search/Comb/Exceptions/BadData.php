<?php

namespace Statamic\Search\Comb\Exceptions;

/**
* Thrown when Comb could not successfully load haystack data
*/
class BadData extends Exception
{

}
