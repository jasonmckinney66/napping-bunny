<?php

namespace Statamic\Stache;

class TimeoutException extends \RuntimeException
{
}
