<?php

namespace Statamic\Stache\Drivers;

interface AggregateDriver
{

}
