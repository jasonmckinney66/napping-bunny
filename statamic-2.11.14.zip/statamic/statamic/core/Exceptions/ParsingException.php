<?php

namespace Statamic\Exceptions;

class ParsingException extends \Exception
{
}
