<?php

namespace Statamic\Exceptions;

/**
 * Trigger a 404
 */
class UrlNotFoundException extends \Exception
{
}
