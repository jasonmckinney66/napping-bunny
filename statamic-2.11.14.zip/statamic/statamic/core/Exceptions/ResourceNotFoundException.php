<?php

namespace Statamic\Exceptions;

/**
 * When a plugin resource is not found. Not necessarily bad.
 */
class ResourceNotFoundException extends \Exception
{
}
