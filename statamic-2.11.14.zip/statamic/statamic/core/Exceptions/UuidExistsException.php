<?php

namespace Statamic\Exceptions;

class UuidExistsException extends \Exception
{
}
