<?php

namespace Statamic\Exceptions;

class ApiNotFoundException extends \Exception
{
}
