<?php

namespace Statamic\Contracts\Data\Pages;

use Statamic\Contracts\Data\DataFolder;

interface PageFolder extends DataFolder
{
}
