<?php

namespace Statamic\Config;

class Addons extends Config
{
    /**
     * Save the config
     *
     * @return void
     */
    public function save()
    {
        // @todo
    }
}
