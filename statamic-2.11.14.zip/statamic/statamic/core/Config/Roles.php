<?php

namespace Statamic\Config;

class Roles extends Config
{
    /**
     * Save the config
     *
     * @return void
     */
    public function save()
    {
        // @todo
    }
}
