title: A Wand
amazon_id: B000BVYQ9O
photo: http://ecx.images-amazon.com/images/I/41H1QM547GL.jpg
id: 39a933d8-9879-424b-8620-852079cdb138
