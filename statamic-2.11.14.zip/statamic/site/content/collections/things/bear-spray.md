title: Bear Spray
amazon_id: B002E6VAHK
photo: http://ecx.images-amazon.com/images/I/61CZuivFwtL.jpg
id: d4510ddc-d0ce-407b-9570-3f86139d0088
