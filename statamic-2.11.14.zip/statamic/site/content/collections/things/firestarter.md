title: Firestarter
amazon_id: B004DT6TEK
photo: http://ecx.images-amazon.com/images/I/715BI00vQHL.jpg
id: 0ebf6f60-b265-457b-aaa3-06dd1248b8c1
