title: Warm Woolen Mittens
amazon_id: B000V5G2SS
photo: http://ecx.images-amazon.com/images/I/81GyabgA1TL.jpg
id: 6e5e6c7a-8e6f-42e1-ae07-dc7078e6564e
