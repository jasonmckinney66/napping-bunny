---
title: Favorite Things
nav_title: Things
template: things
mount: things
id: 26a4ce21-d768-440d-806b-213918df0ee0
---
I use these things on a regular basis out here in the wild. When I'm feeling sad I simply remember them and then I don't feel so bad.
